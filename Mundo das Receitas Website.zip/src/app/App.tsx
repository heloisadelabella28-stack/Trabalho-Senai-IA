import { useState, useEffect } from 'react';
import { Search, Heart, Moon, Sun, ChefHat, Utensils, Coffee, Cake, Salad, Flame, Globe, Pizza, Clock, Users, Star, ShoppingCart, Play, Menu, X } from 'lucide-react';

interface Recipe {
  id: number;
  name: string;
  description: string;
  image: string;
  time: string;
  difficulty: string;
  servings: number;
  rating: number;
  category: string;
  ingredients: string[];
  instructions: string[];
  isQuick?: boolean;
  isEconomical?: boolean;
}

interface Category {
  id: number;
  name: string;
  icon: JSX.Element;
  image: string;
}

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [darkMode, setDarkMode] = useState(false);
  const [favorites, setFavorites] = useState<number[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const categories: Category[] = [
    { id: 1, name: 'Sobremesas', icon: <Cake className="w-8 h-8" />, image: 'https://images.unsplash.com/photo-1551024506-0bccd828d307?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400' },
    { id: 2, name: 'Massas', icon: <Utensils className="w-8 h-8" />, image: 'https://images.unsplash.com/photo-1722938687772-62a0dbfacc25?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400' },
    { id: 3, name: 'Lanches', icon: <Pizza className="w-8 h-8" />, image: 'https://images.unsplash.com/photo-1671106571674-a89083d27e60?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400' },
    { id: 4, name: 'Bebidas', icon: <Coffee className="w-8 h-8" />, image: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400' },
    { id: 5, name: 'Saudáveis', icon: <Salad className="w-8 h-8" />, image: 'https://images.unsplash.com/photo-1692780941266-96892bb6c9df?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400' },
    { id: 6, name: 'Veganas', icon: <Salad className="w-8 h-8" />, image: 'https://images.unsplash.com/photo-1692973702024-b8102e1c2cee?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400' },
    { id: 7, name: 'Churrasco', icon: <Flame className="w-8 h-8" />, image: 'https://images.unsplash.com/photo-1561931557-df299338ab39?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400' },
    { id: 8, name: 'Internacionais', icon: <Globe className="w-8 h-8" />, image: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400' },
  ];

  const recipes: Recipe[] = [
    {
      id: 1,
      name: 'Pizza Margherita Italiana',
      description: 'Pizza artesanal com molho de tomate fresco, mussarela de búfala e manjericão.',
      image: 'https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800',
      time: '40 min',
      difficulty: 'Fácil',
      servings: 4,
      rating: 5,
      category: 'Massas',
      ingredients: ['500g de farinha', '300ml de água morna', '10g de fermento', '1 colher de sal', '3 tomates', '200g de mussarela', 'Manjericão fresco', 'Azeite'],
      instructions: ['Prepare a massa misturando farinha, água, fermento e sal', 'Deixe descansar por 1 hora', 'Abra a massa em formato circular', 'Adicione molho de tomate, queijo e manjericão', 'Asse em forno alto por 12-15 minutos']
    },
    {
      id: 2,
      name: 'Hambúrguer Gourmet',
      description: 'Hambúrguer artesanal com carne suculenta, queijo cheddar e molho especial.',
      image: 'https://images.unsplash.com/photo-1671106571674-a89083d27e60?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800',
      time: '25 min',
      difficulty: 'Médio',
      servings: 2,
      rating: 5,
      category: 'Lanches',
      ingredients: ['400g de carne moída', '2 pães brioche', '4 fatias de cheddar', 'Alface', 'Tomate', 'Cebola roxa', 'Molho especial', 'Picles'],
      instructions: ['Tempere a carne e faça 2 hambúrgueres', 'Grelhe por 4 minutos de cada lado', 'Derreta o queijo sobre a carne', 'Torre os pães', 'Monte com todos os ingredientes'],
      isQuick: true
    },
    {
      id: 3,
      name: 'Bolo de Chocolate Cremoso',
      description: 'Delicioso bolo de chocolate com cobertura ganache.',
      image: 'https://images.unsplash.com/photo-1585504455924-3d3b0eb2b8ee?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800',
      time: '60 min',
      difficulty: 'Médio',
      servings: 8,
      rating: 5,
      category: 'Sobremesas',
      ingredients: ['3 ovos', '2 xícaras de açúcar', '2 xícaras de farinha', '1 xícara de chocolate em pó', '1 xícara de leite', '1/2 xícara de óleo', '1 colher de fermento'],
      instructions: ['Bata os ovos com açúcar', 'Adicione os ingredientes secos', 'Misture o leite e óleo', 'Asse por 40 minutos a 180°C', 'Prepare a ganache e cubra']
    },
    {
      id: 4,
      name: 'Salada Caesar Clássica',
      description: 'Salada fresca com frango grelhado, croutons e molho caesar.',
      image: 'https://images.unsplash.com/photo-1692780941266-96892bb6c9df?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800',
      time: '15 min',
      difficulty: 'Fácil',
      servings: 2,
      rating: 4,
      category: 'Saudáveis',
      ingredients: ['Alface romana', '200g de frango', 'Parmesão', 'Croutons', 'Molho caesar', 'Limão'],
      instructions: ['Grelhe o frango temperado', 'Corte a alface em pedaços', 'Adicione croutons e parmesão', 'Regue com molho caesar', 'Finalize com limão'],
      isQuick: true
    },
    {
      id: 5,
      name: 'Macarrão Carbonara',
      description: 'Pasta italiana cremosa com bacon e queijo parmesão.',
      image: 'https://images.unsplash.com/photo-1723906012573-6513af5a986c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800',
      time: '20 min',
      difficulty: 'Fácil',
      servings: 3,
      rating: 5,
      category: 'Massas',
      ingredients: ['400g de espaguete', '200g de bacon', '4 gemas', '100g de parmesão', 'Pimenta do reino', 'Sal'],
      instructions: ['Cozinhe o macarrão al dente', 'Frite o bacon até ficar crocante', 'Misture gemas com parmesão', 'Combine tudo ainda quente', 'Finalize com pimenta'],
      isQuick: true,
      isEconomical: true
    },
    {
      id: 6,
      name: 'Churrasco Completo',
      description: 'Seleção de carnes nobres grelhadas no ponto perfeito.',
      image: 'https://images.unsplash.com/photo-1561931557-df299338ab39?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800',
      time: '120 min',
      difficulty: 'Difícil',
      servings: 10,
      rating: 5,
      category: 'Churrasco',
      ingredients: ['Picanha 1kg', 'Costela 2kg', 'Linguiça calabresa', 'Sal grosso', 'Alho', 'Carvão'],
      instructions: ['Tempere as carnes com sal grosso', 'Prepare a churrasqueira', 'Asse as carnes gradualmente', 'Controle o ponto de cada carne', 'Sirva quente com acompanhamentos']
    },
    {
      id: 7,
      name: 'Omelete Especial',
      description: 'Omelete fofinho recheado com queijo e vegetais.',
      image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800',
      time: '10 min',
      difficulty: 'Fácil',
      servings: 1,
      rating: 4,
      category: 'Lanches',
      ingredients: ['3 ovos', 'Queijo ralado', 'Tomate', 'Cebola', 'Sal', 'Pimenta', 'Manteiga'],
      instructions: ['Bata os ovos com sal e pimenta', 'Aqueça a manteiga na frigideira', 'Despeje os ovos', 'Adicione recheio de um lado', 'Dobre ao meio e sirva'],
      isQuick: true,
      isEconomical: true
    },
    {
      id: 8,
      name: 'Sushi Variado',
      description: 'Combinado de sushis e sashimis frescos.',
      image: 'https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800',
      time: '90 min',
      difficulty: 'Difícil',
      servings: 4,
      rating: 5,
      category: 'Internacionais',
      ingredients: ['Arroz japonês', 'Nori', 'Salmão fresco', 'Atum', 'Pepino', 'Cream cheese', 'Molho shoyu', 'Wasabi', 'Gengibre'],
      instructions: ['Cozinhe o arroz japonês', 'Tempere com vinagre de arroz', 'Corte os peixes em tiras', 'Monte os sushis e rolls', 'Sirva com shoyu e wasabi']
    }
  ];

  const toggleFavorite = (id: number) => {
    setFavorites(prev =>
      prev.includes(id) ? prev.filter(fav => fav !== id) : [...prev, id]
    );
  };

  const surpriseRecipe = () => {
    const randomRecipe = recipes[Math.floor(Math.random() * recipes.length)];
    setSelectedRecipe(randomRecipe);
  };

  const filteredRecipes = recipes.filter(recipe =>
    recipe.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    recipe.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
    recipe.ingredients.some(ing => ing.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const getShoppingList = () => {
    const favoriteRecipes = recipes.filter(r => favorites.includes(r.id));
    const allIngredients = favoriteRecipes.flatMap(r => r.ingredients);
    return [...new Set(allIngredients)];
  };

  const RecipeCard = ({ recipe, featured = false }: { recipe: Recipe; featured?: boolean }) => (
    <div
      className={`group relative bg-white dark:bg-gray-800 rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 cursor-pointer ${featured ? 'min-w-[350px]' : ''}`}
      onClick={() => setSelectedRecipe(recipe)}
    >
      <div className="relative overflow-hidden">
        <img
          src={recipe.image}
          alt={recipe.name}
          className="w-full h-56 object-cover group-hover:scale-110 transition-transform duration-700"
        />
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleFavorite(recipe.id);
          }}
          className="absolute top-4 right-4 bg-white dark:bg-gray-800 w-12 h-12 rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform duration-300"
        >
          <Heart
            className={`w-6 h-6 ${favorites.includes(recipe.id) ? 'fill-red-500 text-red-500' : 'text-gray-600 dark:text-gray-300'}`}
          />
        </button>
      </div>

      <div className="p-6">
        <h3 className="text-xl font-semibold mb-2 text-gray-800 dark:text-white">{recipe.name}</h3>

        <div className="flex gap-1 mb-3">
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              className={`w-4 h-4 ${i < recipe.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
            />
          ))}
        </div>

        <p className="text-gray-600 dark:text-gray-300 mb-4 line-clamp-2">{recipe.description}</p>

        <div className="flex justify-between items-center text-sm text-gray-500 dark:text-gray-400 mb-4">
          <span className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            {recipe.time}
          </span>
          <span className="flex items-center gap-1">
            <Flame className="w-4 h-4" />
            {recipe.difficulty}
          </span>
          <span className="flex items-center gap-1">
            <Users className="w-4 h-4" />
            {recipe.servings}
          </span>
        </div>

        <button className="w-full bg-gradient-to-r from-orange-500 to-red-500 text-white py-3 rounded-2xl font-semibold hover:from-orange-600 hover:to-red-600 transition-all duration-300">
          Ver Receita Completa
        </button>
      </div>
    </div>
  );

  const CategoryCard = ({ category }: { category: Category }) => (
    <div
      className="group relative bg-white dark:bg-gray-800 rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 cursor-pointer"
      onClick={() => {
        setCurrentPage('categorias');
        setSearchQuery(category.name);
      }}
    >
      <div className="relative overflow-hidden h-40">
        <img
          src={category.image}
          alt={category.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
      </div>
      <div className="p-5 text-center">
        <div className="flex justify-center mb-2 text-orange-500">
          {category.icon}
        </div>
        <h3 className="font-semibold text-gray-800 dark:text-white">{category.name}</h3>
      </div>
    </div>
  );

  const RecipeModal = ({ recipe, onClose }: { recipe: Recipe; onClose: () => void }) => (
    <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-white dark:bg-gray-800 rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="relative">
          <img src={recipe.image} alt={recipe.name} className="w-full h-80 object-cover rounded-t-3xl" />
          <button onClick={onClose} className="absolute top-4 right-4 bg-white dark:bg-gray-800 w-12 h-12 rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-8">
          <h2 className="text-3xl font-bold mb-4 text-gray-800 dark:text-white">{recipe.name}</h2>

          <div className="flex gap-1 mb-4">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className={`w-5 h-5 ${i < recipe.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`} />
            ))}
          </div>

          <p className="text-gray-600 dark:text-gray-300 mb-6">{recipe.description}</p>

          <div className="grid grid-cols-3 gap-4 mb-8">
            <div className="bg-orange-50 dark:bg-gray-700 p-4 rounded-2xl text-center">
              <Clock className="w-6 h-6 mx-auto mb-2 text-orange-500" />
              <p className="text-sm text-gray-600 dark:text-gray-300">Tempo</p>
              <p className="font-semibold text-gray-800 dark:text-white">{recipe.time}</p>
            </div>
            <div className="bg-orange-50 dark:bg-gray-700 p-4 rounded-2xl text-center">
              <Flame className="w-6 h-6 mx-auto mb-2 text-orange-500" />
              <p className="text-sm text-gray-600 dark:text-gray-300">Dificuldade</p>
              <p className="font-semibold text-gray-800 dark:text-white">{recipe.difficulty}</p>
            </div>
            <div className="bg-orange-50 dark:bg-gray-700 p-4 rounded-2xl text-center">
              <Users className="w-6 h-6 mx-auto mb-2 text-orange-500" />
              <p className="text-sm text-gray-600 dark:text-gray-300">Porções</p>
              <p className="font-semibold text-gray-800 dark:text-white">{recipe.servings}</p>
            </div>
          </div>

          <div className="mb-8">
            <h3 className="text-2xl font-semibold mb-4 text-gray-800 dark:text-white">Ingredientes</h3>
            <ul className="space-y-2">
              {recipe.ingredients.map((ingredient, idx) => (
                <li key={idx} className="flex items-start gap-3">
                  <span className="text-orange-500 mt-1">✓</span>
                  <span className="text-gray-700 dark:text-gray-300">{ingredient}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="mb-6">
            <h3 className="text-2xl font-semibold mb-4 text-gray-800 dark:text-white">Modo de Preparo</h3>
            <ol className="space-y-4">
              {recipe.instructions.map((instruction, idx) => (
                <li key={idx} className="flex gap-4">
                  <span className="flex-shrink-0 w-8 h-8 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-full flex items-center justify-center font-semibold">
                    {idx + 1}
                  </span>
                  <span className="text-gray-700 dark:text-gray-300 flex-1 pt-1">{instruction}</span>
                </li>
              ))}
            </ol>
          </div>

          <div className="bg-gradient-to-r from-orange-50 to-red-50 dark:from-gray-700 dark:to-gray-700 p-6 rounded-2xl">
            <h4 className="font-semibold mb-3 text-gray-800 dark:text-white">Comentários dos Usuários</h4>
            <div className="space-y-4">
              <div className="bg-white dark:bg-gray-800 p-4 rounded-xl">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center text-white font-semibold">M</div>
                  <div>
                    <p className="font-semibold text-gray-800 dark:text-white">Maria Silva</p>
                    <div className="flex gap-1">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 dark:text-gray-300 text-sm">Receita maravilhosa! Ficou perfeita e toda família adorou.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const HomePage = () => (
    <>
      <section className="relative h-[90vh] flex items-center justify-center overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center bg-fixed"
          style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1504674900247-0877df9cc836?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1920)' }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/40"></div>

        <div className="relative z-10 text-center text-white px-4 max-w-4xl">
          <h1 className="text-6xl md:text-7xl font-bold mb-6 animate-fade-in">
            Descubra Sabores Incríveis
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-200">
            Explore receitas deliciosas, rápidas e criativas para todos os gostos
          </p>
          <button
            onClick={surpriseRecipe}
            className="bg-gradient-to-r from-orange-500 to-red-500 px-8 py-4 rounded-full text-lg font-semibold hover:from-orange-600 hover:to-red-600 transition-all duration-300 hover:scale-105 shadow-2xl"
          >
            🎲 Receita Surpresa
          </button>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 -mt-8 relative z-20 mb-12">
        <div className="bg-white dark:bg-gray-800 rounded-3xl shadow-2xl p-6 flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Buscar por receita, ingrediente ou categoria..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-4 bg-gray-50 dark:bg-gray-700 rounded-2xl outline-none text-gray-800 dark:text-white"
            />
          </div>
          <button className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-8 py-4 rounded-2xl font-semibold hover:from-orange-600 hover:to-red-600 transition-all duration-300">
            Buscar
          </button>
        </div>
      </div>

      <section className="max-w-7xl mx-auto px-4 py-16">
        <h2 className="text-4xl font-bold mb-10 text-gray-800 dark:text-white">
          Categorias
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {categories.map(category => (
            <CategoryCard key={category.id} category={category} />
          ))}
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 py-16">
        <h2 className="text-4xl font-bold mb-10 text-gray-800 dark:text-white">
          Receitas Populares
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {recipes.slice(0, 6).map(recipe => (
            <RecipeCard key={recipe.id} recipe={recipe} />
          ))}
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 py-16">
        <h2 className="text-4xl font-bold mb-10 text-gray-800 dark:text-white">
          Receitas Rápidas
        </h2>
        <div className="flex gap-6 overflow-x-auto pb-4 scrollbar-custom">
          {recipes.filter(r => r.isQuick).map(recipe => (
            <RecipeCard key={recipe.id} recipe={recipe} featured />
          ))}
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 py-16">
        <h2 className="text-4xl font-bold mb-10 text-gray-800 dark:text-white">
          Receitas Econômicas
        </h2>
        <div className="grid md:grid-cols-2 gap-8">
          {recipes.filter(r => r.isEconomical).map(recipe => (
            <RecipeCard key={recipe.id} recipe={recipe} />
          ))}
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 py-16">
        <h2 className="text-4xl font-bold mb-10 text-gray-800 dark:text-white">
          Vídeo Tutorial em Destaque
        </h2>
        <div className="relative rounded-3xl overflow-hidden shadow-2xl aspect-video bg-gray-900">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center text-white">
              <Play className="w-20 h-20 mx-auto mb-4 opacity-80" />
              <p className="text-xl">Vídeo tutorial em breve</p>
            </div>
          </div>
        </div>
      </section>

      {favorites.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 py-16">
          <h2 className="text-4xl font-bold mb-10 text-gray-800 dark:text-white flex items-center gap-3">
            <ShoppingCart className="w-8 h-8 text-orange-500" />
            Lista Automática de Compras
          </h2>
          <div className="bg-gradient-to-br from-orange-50 to-red-50 dark:from-gray-800 dark:to-gray-700 rounded-3xl p-8 shadow-lg">
            <h3 className="text-2xl font-semibold mb-6 text-gray-800 dark:text-white">
              Ingredientes das suas receitas favoritas:
            </h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
              {getShoppingList().map((ingredient, idx) => (
                <div key={idx} className="flex items-center gap-3 bg-white dark:bg-gray-800 p-3 rounded-xl">
                  <span className="text-green-500 text-xl">✓</span>
                  <span className="text-gray-700 dark:text-gray-300">{ingredient}</span>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}
    </>
  );

  const CategoriasPage = () => (
    <section className="max-w-7xl mx-auto px-4 py-24">
      <h1 className="text-5xl font-bold mb-12 text-gray-800 dark:text-white">
        Todas as Categorias
      </h1>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
        {categories.map(category => (
          <CategoryCard key={category.id} category={category} />
        ))}
      </div>

      {searchQuery && (
        <>
          <h2 className="text-3xl font-bold mb-8 text-gray-800 dark:text-white">
            Receitas: {searchQuery}
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredRecipes.map(recipe => (
              <RecipeCard key={recipe.id} recipe={recipe} />
            ))}
          </div>
        </>
      )}
    </section>
  );

  const ReceitasPopularesPage = () => (
    <section className="max-w-7xl mx-auto px-4 py-24">
      <h1 className="text-5xl font-bold mb-12 text-gray-800 dark:text-white">
        Receitas Populares
      </h1>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {recipes.map(recipe => (
          <RecipeCard key={recipe.id} recipe={recipe} />
        ))}
      </div>
    </section>
  );

  const SobrePage = () => (
    <section className="max-w-4xl mx-auto px-4 py-24">
      <h1 className="text-5xl font-bold mb-8 text-gray-800 dark:text-white">
        Sobre o Mundo das Receitas
      </h1>
      <div className="bg-white dark:bg-gray-800 rounded-3xl p-8 shadow-lg space-y-6">
        <p className="text-lg text-gray-700 dark:text-gray-300 leading-relaxed">
          Bem-vindo ao <span className="font-semibold text-orange-500">Mundo das Receitas</span>, seu destino completo para descobrir, aprender e se apaixonar pela culinária!
        </p>
        <p className="text-lg text-gray-700 dark:text-gray-300 leading-relaxed">
          Nossa missão é tornar a cozinha um lugar de criatividade, alegria e sabor. Com uma coleção cuidadosamente selecionada de receitas de todas as categorias - desde pratos rápidos do dia a dia até experiências gastronômicas sofisticadas - oferecemos inspiração para cozinheiros de todos os níveis.
        </p>
        <div className="grid md:grid-cols-3 gap-6 pt-6">
          <div className="text-center">
            <div className="text-4xl font-bold text-orange-500 mb-2">500+</div>
            <p className="text-gray-600 dark:text-gray-400">Receitas</p>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-orange-500 mb-2">50k+</div>
            <p className="text-gray-600 dark:text-gray-400">Usuários</p>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-orange-500 mb-2">4.8★</div>
            <p className="text-gray-600 dark:text-gray-400">Avaliação</p>
          </div>
        </div>
      </div>
    </section>
  );

  const ContatoPage = () => (
    <section className="max-w-4xl mx-auto px-4 py-24">
      <h1 className="text-5xl font-bold mb-8 text-gray-800 dark:text-white">
        Entre em Contato
      </h1>
      <div className="bg-white dark:bg-gray-800 rounded-3xl p-8 shadow-lg">
        <form className="space-y-6">
          <div>
            <label className="block text-gray-700 dark:text-gray-300 mb-2 font-semibold">Nome</label>
            <input type="text" className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 rounded-xl outline-none text-gray-800 dark:text-white" />
          </div>
          <div>
            <label className="block text-gray-700 dark:text-gray-300 mb-2 font-semibold">Email</label>
            <input type="email" className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 rounded-xl outline-none text-gray-800 dark:text-white" />
          </div>
          <div>
            <label className="block text-gray-700 dark:text-gray-300 mb-2 font-semibold">Mensagem</label>
            <textarea rows={6} className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 rounded-xl outline-none text-gray-800 dark:text-white resize-none"></textarea>
          </div>
          <button type="submit" className="w-full bg-gradient-to-r from-orange-500 to-red-500 text-white py-4 rounded-2xl font-semibold hover:from-orange-600 hover:to-red-600 transition-all duration-300">
            Enviar Mensagem
          </button>
        </form>
      </div>
    </section>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50 dark:from-gray-900 dark:via-gray-900 dark:to-gray-800 transition-colors duration-500">
      <header className="sticky top-0 z-40 bg-gradient-to-r from-orange-500 to-red-500 shadow-lg backdrop-blur-lg">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div
            className="flex items-center gap-2 cursor-pointer"
            onClick={() => setCurrentPage('home')}
          >
            <ChefHat className="w-8 h-8 text-white" />
            <span className="text-2xl font-bold text-white">Mundo das Receitas</span>
          </div>

          <nav className="hidden md:flex gap-8">
            {['Home', 'Categorias', 'Receitas Populares', 'Sobre', 'Contato'].map(page => (
              <button
                key={page}
                onClick={() => setCurrentPage(page.toLowerCase().replace(' ', '-'))}
                className="text-white font-medium hover:text-orange-100 transition-colors duration-300"
              >
                {page}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="bg-white/20 backdrop-blur-sm p-3 rounded-full hover:bg-white/30 transition-all duration-300"
            >
              {darkMode ? <Sun className="w-5 h-5 text-white" /> : <Moon className="w-5 h-5 text-white" />}
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden bg-white/20 backdrop-blur-sm p-3 rounded-full hover:bg-white/30 transition-all duration-300"
            >
              {mobileMenuOpen ? <X className="w-5 h-5 text-white" /> : <Menu className="w-5 h-5 text-white" />}
            </button>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden bg-white/10 backdrop-blur-lg">
            <nav className="flex flex-col p-4 gap-3">
              {['Home', 'Categorias', 'Receitas Populares', 'Sobre', 'Contato'].map(page => (
                <button
                  key={page}
                  onClick={() => {
                    setCurrentPage(page.toLowerCase().replace(' ', '-'));
                    setMobileMenuOpen(false);
                  }}
                  className="text-white font-medium hover:text-orange-100 transition-colors duration-300 text-left py-2"
                >
                  {page}
                </button>
              ))}
            </nav>
          </div>
        )}
      </header>

      <main>
        {currentPage === 'home' && <HomePage />}
        {currentPage === 'categorias' && <CategoriasPage />}
        {currentPage === 'receitas-populares' && <ReceitasPopularesPage />}
        {currentPage === 'sobre' && <SobrePage />}
        {currentPage === 'contato' && <ContatoPage />}
      </main>

      <footer className="bg-gray-900 text-white py-12 mt-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col items-center gap-6">
            <div className="flex items-center gap-2">
              <ChefHat className="w-8 h-8 text-orange-500" />
              <span className="text-2xl font-bold">Mundo das Receitas</span>
            </div>

            <nav className="flex flex-wrap justify-center gap-6">
              {['Home', 'Categorias', 'Receitas Populares', 'Sobre', 'Contato'].map(page => (
                <button
                  key={page}
                  onClick={() => setCurrentPage(page.toLowerCase().replace(' ', '-'))}
                  className="text-gray-300 hover:text-white transition-colors duration-300"
                >
                  {page}
                </button>
              ))}
            </nav>

            <p className="text-gray-400 text-center">
              © 2026 Mundo das Receitas - Todos os direitos reservados.
            </p>
          </div>
        </div>
      </footer>

      {selectedRecipe && (
        <RecipeModal recipe={selectedRecipe} onClose={() => setSelectedRecipe(null)} />
      )}
    </div>
  );
}
